const config = {
    apiUrl: '/api_akira_hatakeyama'
  };
  
  export default config;